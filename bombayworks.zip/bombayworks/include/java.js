 
function shapeCalculator() {
    if (document.getElementById('circle').checked) {
        document.getElementById('form2').style.display = 'block';
        document.getElementById('form3').style.display = 'none';
        document.getElementById('form4').style.display = 'none';
        document.getElementById('form5').style.display = 'none';
    } 
    else if(document.getElementById('ellipse').checked) {
		document.getElementById('form3').style.display = 'block';
        document.getElementById('form2').style.display = 'none';
        document.getElementById('form4').style.display = 'none';
        document.getElementById('form5').style.display = 'none';
   }
   else if(document.getElementById('square').checked) {
	    document.getElementById('form4').style.display = 'block';
        document.getElementById('form2').style.display = 'none';
        document.getElementById('form3').style.display = 'none';
        document.getElementById('form5').style.display = 'none';
   }
   else if(document.getElementById('rectangle').checked) {
	    document.getElementById('form5').style.display = 'block';
        document.getElementById('form2').style.display = 'none';
        document.getElementById('form3').style.display = 'none';
        document.getElementById('form4').style.display = 'none';
   }
}
// Area of a Circle :

function circleArea(){
        var radius = document.getElementById('dc').value;
		var area_circle = radius * radius * Math.PI;
		var ac = document.getElementById('ac');
		ac.value=area_circle;
    }
	

// Area of an Ellipse :
	
function ellipseArea(){
        var height1 = document.getElementById('he').value;
        var width1 = document.getElementById('we').value;
		var area_ellipse = height1 * width1 * Math.PI;
		var ae = document.getElementById('ae');
		ae.value=area_ellipse;
    }	
	
// Area of a Square : 
	
function squareArea(){
        var width = document.getElementById('ws').value;
		var area_square = 2 * width;
        var as = document.getElementById('as');
		as.value=area_square;
    }	

// Area of a Rectangle :
	
function rectangleArea(){
        var height2 = document.getElementById('hr').value;
        var width2 = document.getElementById('wr').value;
		var area_rectangle = height2 * width2 ;
		var ar = document.getElementById('ar');
		ar.value=area_rectangle;
    }		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	